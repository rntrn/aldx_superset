from abc import ABC, abstractmethod
from collections.abc import Iterator, Sequence
from typing import Any

Matrix = Sequence[Sequence[Any]]


class Closable(ABC):
    @abstractmethod
    def close(self) -> None:
        pass


class ByteSource(Closable):
    last_message: bytes | None = None
    gen: Iterator[bytes]
    exception_tag: str | None = None

    @abstractmethod
    def read_leb128(self) -> int:
        pass

    @abstractmethod
    def read_leb128_str(self) -> str:
        pass

    @abstractmethod
    def read_uint64(self) -> int:
        pass

    @abstractmethod
    def read_bytes(self, sz: int) -> bytes:
        pass

    @abstractmethod
    def read_str_col(self, num_rows: int, encoding: str | None, nullable: bool = False, null_obj: Any = None) -> Any:
        pass

    @abstractmethod
    def read_bytes_col(self, sz: int, num_rows: int) -> Any:
        pass

    @abstractmethod
    def read_fixed_str_col(self, sz: int, num_rows: int, encoding: str) -> Any:
        pass

    @abstractmethod
    def read_array(self, array_type: str, num_rows: int) -> Any:
        pass

    @abstractmethod
    def read_byte(self) -> int:
        pass
