import asyncio
import logging
import queue
import threading
import weakref
import zlib
from collections.abc import Callable, Iterable, Iterator
from typing import cast

import lz4.frame

from clickhouse_connect.driver.asyncqueue import EOF_SENTINEL, AsyncSyncQueue
from clickhouse_connect.driver.asyncqueue import Full as AsyncQueueFull
from clickhouse_connect.driver.compression import _zstd_decompressor, available_compression
from clickhouse_connect.driver.exceptions import Error, OperationalError
from clickhouse_connect.driver.transform import Transform
from clickhouse_connect.driver.types import ByteSource, Closable

logger: logging.Logger = logging.getLogger(__name__)

__all__ = [
    "StreamingResponseSource",
    "StreamingFileAdapter",
    "StreamingInsertSource",
    "ReadAheadSource",
    "QueuedStreamSource",
    "start_streaming_response",
]

if "br" in available_compression:
    import brotli
else:
    brotli = None


class StreamingResponseSource(Closable):
    """Streaming source that feeds chunks from async producer to sync consumer."""

    READ_BUFFER_SIZE = 1024 * 1024

    def __init__(self, response, encoding: str | None = None, exception_tag: str | None = None):
        self.response = response
        self.encoding = encoding
        self.exception_tag = exception_tag

        # maxsize=10 means max ~10 socket reads buffered
        self.queue: AsyncSyncQueue[bytes | Exception] = AsyncSyncQueue(maxsize=10)

        self._decompressor = None
        self._decompressor_initialized = False

        # Multiple accesses to .gen must return the same generator, not create new ones
        self._gen_cache: Iterator[bytes] | None = None

        self._loop: asyncio.AbstractEventLoop | None = None
        self._producer_task: asyncio.Task | None = None
        self._producer_started = threading.Event()
        self._producer_error: Exception | None = None
        self._producer_completed = False
        self._lease_lock = threading.Lock()
        self._lease_released = False

    def _release_lease(self):
        with self._lease_lock:
            if self._lease_released:
                return
            self._lease_released = True
        release = getattr(self.response, "_lease_release", None)
        if release is None:
            return
        loop = self._loop
        if loop is not None and not loop.is_closed():
            try:
                current_loop = asyncio.get_running_loop()
            except RuntimeError:
                current_loop = None
            if current_loop is loop:
                release()
                return
            try:
                loop.call_soon_threadsafe(release)
            except RuntimeError:
                pass
            else:
                return
        release()

    @staticmethod
    def _retrieve_producer_task_result(task: asyncio.Task) -> None:
        if task.cancelled():
            return
        try:
            task.result()
        except Exception:
            logger.debug("Discarded producer error during streaming response cleanup", exc_info=True)

    async def start_producer(self, loop: asyncio.AbstractEventLoop):
        """Start the async producer task.
        Must be called from the event loop thread before consuming.
        """

        async def producer():
            """Async producer: reads chunks from response, feeds queue."""
            data_sent = False
            try:
                while True:
                    chunk = await self.response.content.read(self.READ_BUFFER_SIZE)
                    if not chunk:
                        break
                    data_sent = True
                    await self.queue.async_q.put(chunk)

                await self.queue.async_q.put(EOF_SENTINEL)
                self._producer_completed = True

            except asyncio.CancelledError:
                try:
                    if self.response and not self.response.closed:
                        self.response.close()
                except Exception:
                    logger.debug("Failed to close cancelled streaming response", exc_info=True)
                raise
            except Exception as e:
                logger.error("Producer error while streaming response: %s", e, exc_info=True)
                if not data_sent:
                    e = OperationalError("Failed to read response data from server")
                self._producer_error = e

                try:
                    await self.queue.async_q.put(e)
                except RuntimeError:
                    pass

            finally:
                try:
                    self.queue.shutdown()
                finally:
                    self._release_lease()

        self._loop = loop
        self._producer_task = loop.create_task(producer())
        self._producer_started.set()

    @property
    def gen(self) -> Iterator[bytes]:
        """Generator that yields decompressed chunks.

        CRITICAL: Returns cached generator to prevent multiple generators
        from competing to read from the same queue.
        """
        if self._gen_cache is not None:
            return self._gen_cache

        self._gen_cache = self._create_generator()
        return self._gen_cache

    def _create_generator(self) -> Iterator[bytes]:
        """Creates the actual generator function."""
        if not self._producer_started.wait(timeout=5.0):
            raise RuntimeError("Producer failed to start within timeout")

        if self.encoding and not self._decompressor_initialized:
            self._decompressor_initialized = True
            try:
                self._decompressor = self._create_decompressor(self.encoding)
            except Exception as e:
                logger.error("Failed to create decompressor for %s: %s", self.encoding, e)
                raise

        while True:
            chunk = self.queue.sync_q.get()

            if chunk is EOF_SENTINEL:
                if self._decompressor:
                    try:
                        if hasattr(self._decompressor, "flush"):
                            final = self._decompressor.flush()
                            if final:
                                yield final
                    except Exception as e:
                        logger.error("Error flushing decompressor: %s", e, exc_info=True)
                        raise
                break

            if isinstance(chunk, Exception):
                raise chunk

            if self._decompressor:
                try:
                    if hasattr(self._decompressor, "decompress"):
                        decompressed = self._decompressor.decompress(chunk)
                    else:
                        decompressed = self._decompressor.process(chunk)
                    if decompressed:
                        yield decompressed
                except Exception as e:
                    logger.error("Decompression error: %s", e, exc_info=True)
                    raise
            else:
                yield chunk

    @staticmethod
    def _create_decompressor(encoding: str):
        """Create incremental decompressor for encoding."""
        if encoding == "gzip":
            return zlib.decompressobj(16 + zlib.MAX_WBITS)

        if encoding == "deflate":
            return zlib.decompressobj()

        if encoding == "br":
            if brotli is not None:
                return brotli.Decompressor()
            raise ImportError("brotli compression requires 'brotli' package. Install with: pip install brotli")

        if encoding == "zstd":
            return _zstd_decompressor()

        if encoding == "lz4":
            return lz4.frame.LZ4FrameDecompressor()

        raise ValueError(f"Unsupported compression encoding: {encoding}")

    async def aclose(self):
        """Async cleanup resources"""
        try:
            try:
                self.queue.shutdown()
                if self._producer_task and not self._producer_task.done():
                    self._producer_task.cancel()
                    try:
                        done, _ = await asyncio.wait((self._producer_task,))
                    except asyncio.CancelledError:
                        self._producer_task.add_done_callback(self._retrieve_producer_task_result)
                        raise
                    for task in done:
                        self._retrieve_producer_task_result(task)
            finally:
                if self.response and not self.response.closed:
                    if not self._producer_completed:
                        self.response.close()
                        await asyncio.sleep(0.05)
        finally:
            self._release_lease()

    def close(self):
        """Synchronous cleanup resources"""

        def cleanup():
            if self._producer_task and not self._producer_task.done():
                self._producer_task.cancel()
            if self.response and not self.response.closed:
                if not self._producer_completed:
                    self.response.close()

        try:
            try:
                self.queue.shutdown()
            finally:
                # Task cancellation and aiohttp response teardown must run on the event
                # loop thread. close() is normally called from an executor thread.
                if self._loop is not None and not self._loop.is_closed():
                    try:
                        self._loop.call_soon_threadsafe(cleanup)
                    except RuntimeError:
                        cleanup()
                else:
                    cleanup()
        finally:
            self._release_lease()


async def start_streaming_response(response, encoding: str | None = None, exception_tag: str | None = None) -> StreamingResponseSource:
    """Create a StreamingResponseSource and start its producer on the running loop.

    This is the async byte bridge: an async producer reads response chunks onto
    a bounded queue that a sync consumer (usually parsing in an executor) drains.
    """
    source = StreamingResponseSource(response, encoding=encoding, exception_tag=exception_tag)
    await source.start_producer(asyncio.get_running_loop())
    return source


class QueuedStreamSource(Closable):
    """A streaming source paired with the bounded queue that feeds parsed items
    from a sync producer (running in an executor) to an async consumer."""

    def __init__(self, source: StreamingResponseSource, maxsize: int = 10):
        self.source = source
        self.queue: AsyncSyncQueue = AsyncSyncQueue(maxsize=maxsize)

    def pump(self, produce: Callable[[], Iterable]) -> None:
        """Run produce() in an executor, feeding its items into the queue.
        Must be called from the event loop thread. A RuntimeError from a queue
        put means the queue was shut down and ends the producer quietly; any
        error from produce() itself is queued for the consumer to raise."""
        queue = self.queue

        def producer():
            try:
                for item in produce():
                    try:
                        queue.sync_q.put(item)
                    except RuntimeError:
                        return
                try:
                    queue.sync_q.put(EOF_SENTINEL)
                except RuntimeError:
                    return
            except Exception as e:
                try:
                    queue.sync_q.put(e)
                except Exception:
                    pass
            finally:
                queue.shutdown()

        asyncio.get_running_loop().run_in_executor(None, producer)

    async def items(self):
        """Async generator yielding queued items without blocking the event loop."""
        while True:
            item = await self.queue.async_q.get()
            if item is EOF_SENTINEL:
                break
            if isinstance(item, Exception):
                raise item
            yield item

    async def aclose(self):
        self.queue.shutdown()
        await self.source.aclose()

    def close(self):
        self.queue.shutdown()
        self.source.close()


class StreamingFileAdapter:
    """File-like adapter for PyArrow streaming."""

    def __init__(self, streaming_source):
        self.streaming_source = streaming_source
        self.gen = streaming_source.gen
        self.buffer = b""
        self.closed = False
        self.eof = False

    def read(self, size: int = -1) -> bytes:
        """Read up to size bytes from stream"""
        if self.closed or self.eof:
            return b""

        if size != -1 and len(self.buffer) >= size:
            result = self.buffer[:size]
            self.buffer = self.buffer[size:]
            return result

        chunks = [self.buffer] if self.buffer else []
        current_len = len(self.buffer)
        self.buffer = b""

        while (size == -1 or current_len < size) and not self.eof:
            try:
                chunk = next(self.gen)
                if chunk:
                    chunks.append(chunk)
                    current_len += len(chunk)
                else:
                    self.eof = True
                    break
            except StopIteration:
                self.eof = True
                break

        full_data = b"".join(chunks)

        if size == -1 or len(full_data) <= size:
            return full_data

        result = full_data[:size]
        self.buffer = full_data[size:]
        return result

    def close(self):
        self.closed = True


class StreamingInsertSource:
    """Streaming source for async inserts (reverse bridge)"""

    def __init__(self, transform: Transform, context, loop: asyncio.AbstractEventLoop, maxsize: int = 10):
        self.transform = transform
        self.context = context
        self.loop = loop
        self.queue: AsyncSyncQueue[bytes | bytearray | Exception] = AsyncSyncQueue(maxsize=maxsize)
        self.insert_exception: Exception | None = None
        self._stop_event = threading.Event()
        self._producer_future = None
        self._started = False

    def _record_insert_exception(self, ex: Exception) -> None:
        if self.insert_exception is None:
            self.insert_exception = ex

    def start_producer(self):
        if self._started:
            raise RuntimeError("Producer already started")
        self._started = True

        def producer():
            try:
                block_gen = self.transform.build_insert(self.context, self._record_insert_exception)
                while not self._stop_event.is_set():
                    try:
                        block = next(block_gen)
                    except StopIteration:
                        self._put(EOF_SENTINEL)
                        return

                    if not self._put(block):
                        return

            except Exception as e:
                # Driver errors are deterministic client-side refusals, not operational failures.
                if isinstance(e, Error):
                    logger.debug("Insert producer error: %s", e)
                else:
                    logger.error("Insert producer error: %s", e, exc_info=True)
                self._record_insert_exception(e)
                if not self._stop_event.is_set():
                    self._put(e)
            finally:
                self.queue.shutdown()

        self._producer_future = self.loop.run_in_executor(None, producer)

    async def async_generator(self):
        """Async generator that yields blocks for aiohttp streaming."""
        if not self._started:
            raise RuntimeError("Producer not started, call start_producer() first")

        try:
            while True:
                chunk = await self.queue.async_q.get()

                if chunk is EOF_SENTINEL:
                    break

                if isinstance(chunk, Exception):
                    raise chunk

                yield chunk

        except Exception as e:
            if isinstance(e, Error):
                logger.debug("Insert consumer error: %s", e)
            else:
                logger.error("Insert consumer error: %s", e, exc_info=True)
            raise
        finally:
            self._stop_event.set()
            self.queue.shutdown()
            if self._producer_future and not self._producer_future.done():
                try:
                    await self._producer_future
                except Exception:
                    pass

    async def close(self, timeout: float | None = 1.0):
        """Shut down the queue and wait for the producer thread to terminate. Pass ``timeout=None`` to wait without a deadline."""
        self._stop_event.set()
        self.queue.shutdown()
        if self._producer_future and not self._producer_future.done():
            try:
                if timeout is None:
                    await self._producer_future
                else:
                    await asyncio.wait_for(asyncio.shield(self._producer_future), timeout=timeout)
            except asyncio.TimeoutError:
                logger.warning("Insert producer did not finish within timeout")
            except Exception:
                pass

    def _put(self, item: bytes | bytearray | Exception) -> bool:
        while not self._stop_event.is_set():
            try:
                self.queue.sync_q.put(item, timeout=0.1)
                return True
            except AsyncQueueFull:
                continue
            except RuntimeError:
                return False
        return False


def _read_ahead_producer(
    src_gen: Iterator[bytes],
    out: queue.Queue[tuple[str, object]],
    stop_event: threading.Event,
) -> None:
    def put(item: tuple[str, object]) -> bool:
        while not stop_event.is_set():
            try:
                out.put(item, timeout=0.1)
                return True
            except queue.Full:
                continue
        return False

    try:
        for chunk in src_gen:
            if not put(("data", chunk)):
                return
    except BaseException as ex:  # noqa: BLE001 - forwarded to the consumer thread verbatim
        put(("error", ex))
    finally:
        try:
            # The producer owns this iterator. Free-threaded Python may defer its
            # finalizer after thread exit, so close it before reporting completion.
            close = getattr(src_gen, "close", None)
            if close is not None:
                close()
        except BaseException as ex:  # noqa: BLE001 - preserve stream error forwarding
            put(("error", ex))
        finally:
            put(("eof", None))


def _read_ahead_consumer(source_queue: queue.Queue[tuple[str, object]], stop_event: threading.Event) -> Iterator[bytes]:
    while not stop_event.is_set():
        try:
            tag, payload = source_queue.get(timeout=0.1)
        except queue.Empty:
            continue
        if tag == "data":
            yield cast(bytes, payload)
        elif tag == "error":
            raise cast(BaseException, payload)
        else:  # eof
            return


def _read_ahead_stream(
    owner_ref: "weakref.ref[ReadAheadSource]",
    source: ByteSource,
    out: queue.Queue[tuple[str, object]],
    stop_event: threading.Event,
) -> Iterator[bytes]:
    # Return the first chunk immediately. Read the second only when the consumer asks for more, so empty and
    # single-chunk responses never start a producer. The weak owner reference lets abandoned sources finalize.
    if stop_event.is_set():
        return
    src_gen = source.gen
    try:
        first = next(src_gen)
    except StopIteration:
        return
    yield first
    if stop_event.is_set():
        return
    try:
        second = next(src_gen)
    except StopIteration:
        return
    owner = owner_ref()
    if owner is None or stop_event.is_set():
        return
    thread = threading.Thread(
        target=_read_ahead_producer,
        args=(src_gen, out, stop_event),
        name="clickhouse-read-ahead",
        daemon=True,
    )
    with owner._release_lock:
        if stop_event.is_set():
            return
        thread.start()
        owner._thread = thread
    del owner
    # Let the producer finalize the iterator when it exits, including during async source cleanup.
    del src_gen
    yield second
    yield from _read_ahead_consumer(out, stop_event)


def _drain_read_ahead_queue(source_queue: queue.Queue[tuple[str, object]]) -> None:
    try:
        while True:
            source_queue.get_nowait()
    except queue.Empty:
        pass


def _release_abandoned_read_ahead(source: ByteSource, source_queue: queue.Queue[tuple[str, object]]) -> None:
    try:
        _drain_read_ahead_queue(source_queue)
    finally:
        try:
            source.close()
        except Exception:  # noqa: BLE001 - finalizers must not raise
            pass


async def _wait_for_cleanup(
    future: asyncio.Future,
    cancelled: asyncio.CancelledError | None = None,
) -> asyncio.CancelledError | None:
    while not future.done():
        try:
            await asyncio.wait((future,))
        except asyncio.CancelledError as ex:
            if cancelled is None:
                cancelled = ex
    future.result()
    return cancelled


async def _join_read_ahead_producer(
    thread: threading.Thread,
    cancelled: asyncio.CancelledError | None,
) -> asyncio.CancelledError | None:
    try:
        join_future = asyncio.get_running_loop().run_in_executor(None, thread.join, 1.0)
    except RuntimeError:
        # The default executor is shut down. Skip the bounded join rather than block the loop.
        return cancelled
    return await _wait_for_cleanup(join_future, cancelled)


def _finalize_read_ahead_off_loop(
    source: ByteSource,
    source_queue: queue.Queue[tuple[str, object]],
    producer_thread: threading.Thread | None,
) -> None:
    try:
        if producer_thread is not None and producer_thread.is_alive():
            producer_thread.join(timeout=1.0)
    except Exception:  # noqa: BLE001 - finalizers must not raise
        pass
    _release_abandoned_read_ahead(source, source_queue)


class ReadAheadSource(Closable):
    """Reads chunks from a byte source on a daemon thread into a bounded queue so transport overlaps decode.

    The producer thread starts lazily, once the source yields a second chunk, so empty and single-chunk responses
    never pay for it. The consumer generator re-raises any producer-side exception verbatim, in stream order, so
    the wrapping codec's error mapping, exception-tag scanning, and last-chunk heuristics run unchanged on the
    consumer thread.
    """

    def __init__(self, source: ByteSource, maxsize: int = 16):
        self.source: ByteSource | None = source
        self.exception_tag: str | None = getattr(source, "exception_tag", None)
        self.queue: queue.Queue[tuple[str, object]] = queue.Queue(maxsize=maxsize)
        self._stop_event = threading.Event()
        self._release_lock = threading.Lock()
        self._gen_cache: Iterator[bytes] | None = None
        self._thread: threading.Thread | None = None

    def __del__(self) -> None:
        try:
            if self._stop_event.is_set():
                return
            try:
                loop = asyncio.get_running_loop()
            except RuntimeError:
                self.close()
                return

            self._stop_event.set()
            source = self._take_source()
            if source is None:
                return
            try:
                loop.run_in_executor(
                    None,
                    _finalize_read_ahead_off_loop,
                    source,
                    self.queue,
                    self._thread,
                )
            except Exception:
                _finalize_read_ahead_off_loop(source, self.queue, self._thread)
        except Exception:  # noqa: BLE001 - finalizers must not raise
            pass

    @property
    def gen(self) -> Iterator[bytes]:
        if self._gen_cache is None:
            source = self.source
            if source is None:
                raise RuntimeError("ReadAheadSource is closed")
            self._gen_cache = _read_ahead_stream(weakref.ref(self), source, self.queue, self._stop_event)
        return self._gen_cache

    def _drain(self):
        _drain_read_ahead_queue(self.queue)

    def _take_source(self) -> ByteSource | None:
        with self._release_lock:
            source, self.source = self.source, None
        return source

    def close(self) -> None:
        # Let queue-blocked producers exit first. The source owns any pending transport read
        # and must synchronize or cancel it during close.
        self._stop_event.set()
        with self._release_lock:
            thread = self._thread
        # A finalizer on the producer thread may run inside Queue.put while it holds the queue mutex.
        on_producer = thread is threading.current_thread()
        if thread is not None and not on_producer and thread.is_alive():
            thread.join(timeout=1.0)
        if not on_producer:
            self._drain()
        source = self._take_source()
        if source is not None:
            source.close()

    async def aclose(self) -> None:
        self._stop_event.set()
        cancelled: asyncio.CancelledError | None = None
        cleanup_error: BaseException | None = None
        with self._release_lock:
            thread = self._thread
        if thread is not None and thread.is_alive():
            # Join off the event loop so the worst-case wait never blocks it.
            try:
                cancelled = await _join_read_ahead_producer(thread, cancelled)
            except BaseException as ex:  # noqa: BLE001 - source cleanup must still run
                cleanup_error = ex
        self._drain()
        source = self._take_source()
        if source is not None:
            try:
                aclose = getattr(source, "aclose", None)
                if aclose is not None:
                    cancelled = await _wait_for_cleanup(asyncio.ensure_future(aclose()), cancelled)
                else:
                    source.close()
            except BaseException as ex:  # noqa: BLE001 - preserve cancellation after cleanup
                if cleanup_error is None:
                    cleanup_error = ex
        # A source close can unblock a producer whose in-flight read outlived the first bounded join.
        # Wait once more so async cleanup does not return while that producer is still unwinding.
        if thread is not None and thread.is_alive():
            try:
                cancelled = await _join_read_ahead_producer(thread, cancelled)
            except BaseException as ex:  # noqa: BLE001 - preserve the first cleanup failure
                if cleanup_error is None:
                    cleanup_error = ex
        if cancelled is not None:
            if cleanup_error is not None:
                raise cancelled from cleanup_error
            raise cancelled
        if cleanup_error is not None:
            raise cleanup_error


class _SyncStreamingInsertSource:
    """Bounded producer/consumer source for sync inserts."""

    def __init__(self, transform: Transform, context, maxsize: int = 10):
        self.transform = transform
        self.context = context
        self.queue: queue.Queue[bytes | Exception | object] = queue.Queue(maxsize=maxsize)
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None
        self._started = False

    def start_producer(self):
        if self._started:
            raise RuntimeError("Producer already started")
        self._started = True
        self._thread = threading.Thread(target=self._producer, name="clickhouse-insert-producer", daemon=True)
        self._thread.start()

    @property
    def gen(self) -> Iterator[bytes]:
        if not self._started:
            raise RuntimeError("Producer not started, call start_producer() first")
        try:
            while True:
                chunk = self.queue.get()
                if chunk is EOF_SENTINEL:
                    break
                if isinstance(chunk, Exception):
                    raise chunk
                yield cast(bytes, chunk)
        finally:
            self.close()

    def close(self, timeout: float | None = 1.0):
        self._stop_event.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=timeout)

    def _producer(self):
        try:
            block_gen = self.transform.build_insert(self.context)
            while not self._stop_event.is_set():
                try:
                    block = next(block_gen)
                except StopIteration:
                    self._put(EOF_SENTINEL)
                    return
                if not self._put(block):
                    return
        except Exception as ex:
            # Driver errors are deterministic client-side refusals, not operational failures.
            if isinstance(ex, Error):
                logger.debug("Insert producer error: %s", ex)
            else:
                logger.error("Insert producer error: %s", ex, exc_info=True)
            if getattr(self.context, "insert_exception", None) is None:
                self.context.insert_exception = ex
            if not self._stop_event.is_set():
                self._put(ex)

    def _put(self, item: bytes | Exception | object) -> bool:
        while not self._stop_event.is_set():
            try:
                self.queue.put(item, timeout=0.1)
                return True
            except queue.Full:
                continue
        return False
