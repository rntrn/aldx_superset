from __future__ import annotations

from types import SimpleNamespace
from typing import Any, Literal, cast

from alembic.ddl.impl import DefaultImpl
from alembic.util import CommandError
from sqlalchemy import Column, Index, MetaData, String, Table, TypeDecorator, text
from sqlalchemy.sql.dml import Delete, Update
from sqlalchemy.sql.elements import quoted_name

from clickhouse_connect.cc_sqlalchemy.datatypes.base import ChSqlaType, sqla_type_from_name
from clickhouse_connect.cc_sqlalchemy.datatypes.sqltypes import JSON as ChSqlaJSON  # noqa: N811
from clickhouse_connect.cc_sqlalchemy.datatypes.sqltypes import AggregateFunction as ChSqlaAggregateFunction
from clickhouse_connect.cc_sqlalchemy.datatypes.sqltypes import Array as ChSqlaArray
from clickhouse_connect.cc_sqlalchemy.datatypes.sqltypes import Enum as ChSqlaEnum
from clickhouse_connect.cc_sqlalchemy.datatypes.sqltypes import Map as ChSqlaMap
from clickhouse_connect.cc_sqlalchemy.datatypes.sqltypes import Nested as ChSqlaNested
from clickhouse_connect.cc_sqlalchemy.datatypes.sqltypes import Nullable
from clickhouse_connect.cc_sqlalchemy.datatypes.sqltypes import SimpleAggregateFunction as ChSqlaSimpleAggregateFunction
from clickhouse_connect.cc_sqlalchemy.datatypes.sqltypes import Tuple as ChSqlaTuple
from clickhouse_connect.cc_sqlalchemy.datatypes.sqltypes import _Variant as ChSqlaVariant
from clickhouse_connect.cc_sqlalchemy.ddl.tableengine import MergeTree
from clickhouse_connect.cc_sqlalchemy.inspector import with_internal_query_formats
from clickhouse_connect.cc_sqlalchemy.sql import full_table
from clickhouse_connect.cc_sqlalchemy.sql.ddlcompiler import (
    ClickHouseDDLHelper,
    column_specification,
)
from clickhouse_connect.datatypes.dynamic import JSON as ChJSON  # noqa: N811
from clickhouse_connect.datatypes.registry import parse_name
from clickhouse_connect.driver.binding import quote_identifier

__all__ = ["ClickHouseImpl"]

_STANDARD_INDEX_MESSAGE = (
    "ClickHouse data skipping indexes cannot be created with SQLAlchemy Index, "
    "Column(index=True), op.create_index, or op.drop_index. Use op.add_clickhouse_index "
    "and op.drop_clickhouse_index for ClickHouse data skipping indexes, or op.execute "
    "for custom DDL."
)


def _has_standard_index(table: Table) -> bool:
    return bool(table.indexes) or any(bool(getattr(column, "index", False)) for column in table.columns)


def _reject_standard_index() -> None:
    raise CommandError(_STANDARD_INDEX_MESSAGE)


def _contains_named_container(type_obj: ChSqlaType) -> bool:
    if isinstance(type_obj, ChSqlaNested) or (isinstance(type_obj, ChSqlaTuple) and type_obj.type_def.keys):
        return True
    if isinstance(type_obj, ChSqlaArray):
        nested_types = type_obj.type_def.values[:1]
    elif isinstance(type_obj, (ChSqlaMap, ChSqlaTuple)):
        nested_types = type_obj.type_def.values
    else:
        return False
    return any(_contains_named_container(sqla_type_from_name(str(name))) for name in nested_types)


def _render_ch_type(type_obj):
    """Render a ChSqlaType as valid Python source for autogen migrations"""
    if isinstance(type_obj, (ChSqlaAggregateFunction, ChSqlaSimpleAggregateFunction, ChSqlaVariant)):
        return f"sqla_type_from_name({type_obj.name!r})"
    if _contains_named_container(type_obj):
        return f"sqla_type_from_name({type_obj.name!r})"
    wrappers = type_obj.type_def.wrappers
    if isinstance(type_obj, ChSqlaEnum):
        keys = list(type_obj.type_def.keys)
        values = list(type_obj.type_def.values)
        rendered = f"{type_obj.__class__.__name__}(keys={keys!r}, values={values!r})"
    elif isinstance(type_obj, ChSqlaArray):
        rendered = f"Array({_render_inner(type_obj.type_def.values[0])})"
    elif isinstance(type_obj, ChSqlaMap):
        key, value = type_obj.type_def.values
        rendered = f"Map({_render_inner(key)}, {_render_inner(value)})"
    elif isinstance(type_obj, ChSqlaTuple):
        elements = ", ".join(_render_inner(v) for v in type_obj.type_def.values)
        rendered = f"Tuple({elements})"
    elif isinstance(type_obj, ChSqlaJSON):
        ch_type = cast(ChJSON, type_obj.ch_type)
        args = []
        typed_paths = ", ".join(f"{path!r}: {path_type.name!r}" for path, path_type in zip(ch_type.typed_paths, ch_type.typed_types))
        if typed_paths:
            args.append(f"typed_paths={{{typed_paths}}}")
        configured_limits = {
            key: int(value)
            for key, value in zip(ch_type.type_def.keys, ch_type.type_def.values)
            if key in ("max_dynamic_paths", "max_dynamic_types")
        }
        if "max_dynamic_paths" in configured_limits:
            args.append(f"max_dynamic_paths={configured_limits['max_dynamic_paths']}")
        if "max_dynamic_types" in configured_limits:
            args.append(f"max_dynamic_types={configured_limits['max_dynamic_types']}")
        if ch_type.skip_paths:
            args.append(f"skip_paths={ch_type.skip_paths!r}")
        if ch_type.skip_regexps:
            args.append(f"skip_regexps={ch_type.skip_regexps!r}")
        rendered = f"JSON({', '.join(args)})" if args else "JSON"
    else:
        return str(type_obj.name)
    for wrapper in reversed(wrappers):
        rendered = f"{wrapper}({rendered})"
    return rendered


def _render_inner(name):
    return _render_ch_type(sqla_type_from_name(name))


class ClickHouseImpl(DefaultImpl):
    """Alembic DDL implementation for the ClickHouse SQLAlchemy dialect."""

    __dialect__ = "clickhousedb"
    transactional_ddl = False

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._add_integration_tag()
        if (
            not self.as_sql
            and self.context_opts.get("include_schemas")
            and self.context_opts.get("version_table_schema") is None
            and self.connection is not None
        ):
            current_database = self.connection.execute(with_internal_query_formats(text("SELECT currentDatabase()"))).scalar()
            if current_database:
                self.context_opts["version_table_schema"] = current_database

    def _add_integration_tag(self) -> None:
        if self.connection is None:
            return
        try:
            pool_connection = self.connection.connection
            dbapi_connection = pool_connection.dbapi_connection
            get_driver_connection = getattr(self.dialect, "get_driver_connection", None)
            driver_connection = get_driver_connection(dbapi_connection) if get_driver_connection is not None else dbapi_connection
            client = getattr(driver_connection, "client", driver_connection)
            add_integration_tag = getattr(client, "_add_integration_tag", None)
            if add_integration_tag is not None:
                add_integration_tag("alembic")
        except Exception:
            pass

    def version_table_impl(
        self,
        *,
        version_table: str,
        version_table_schema: str | None,
        version_table_pk: bool,
        **_kw: Any,
    ) -> Table:
        return Table(
            version_table,
            MetaData(),
            Column("version_num", String(32), nullable=False),
            MergeTree(order_by="version_num"),
            schema=version_table_schema,
        )

    def _exec(
        self,
        construct,
        execution_options=None,
        multiparams=None,
        params=None,
    ) -> Any:
        if isinstance(construct, Update) and self._is_version_table_construct(construct):
            return self._exec_version_update(construct, execution_options)
        if isinstance(construct, Delete) and self._is_version_table_construct(construct):
            return self._exec_version_delete(construct, execution_options)
        return super()._exec(
            construct,
            execution_options=execution_options,
            multiparams=multiparams,
            params=params or {},  # type: ignore[arg-type]
        )

    def add_column(
        self,
        table_name: str,
        column: Column,
        *,
        schema: str | None = None,
        if_not_exists: bool | None = None,
        **kw: Any,
    ) -> None:
        if getattr(column, "index", False):
            _reject_standard_index()
        sql = [
            "ALTER TABLE",
            full_table(table_name, schema),
            "ADD COLUMN",
        ]
        if if_not_exists:
            sql.append("IF NOT EXISTS")
        sql.append(column_specification(self.dialect, column))
        after = kw.get("after") or ClickHouseDDLHelper.get_option(column, "after")
        if after:
            sql.extend(["AFTER", quote_identifier(after)])
        settings = ClickHouseDDLHelper.render_settings(kw.get("clickhouse_settings"))
        if settings:
            sql.extend(["SETTINGS", settings])
        self._exec(text(" ".join(sql)))

    def create_table(self, table: Table, **kw: Any) -> None:
        if _has_standard_index(table):
            _reject_standard_index()
        super().create_table(table, **kw)

    def prep_table_for_batch(self, batch_impl: Any, table: Table) -> None:
        """Reject unsupported SQLAlchemy indexes before batch DDL starts."""
        batch_indexes = batch_impl.new_indexes
        existing_indexes = batch_impl.indexes
        if batch_indexes or existing_indexes or _has_standard_index(table):
            _reject_standard_index()
        super().prep_table_for_batch(batch_impl, table)

    def drop_column(
        self,
        table_name: str,
        column: Column,
        *,
        schema: str | None = None,
        if_exists: bool | None = None,
        **kw: Any,
    ) -> None:
        sql = ["ALTER TABLE", full_table(table_name, schema), "DROP COLUMN"]
        if if_exists:
            sql.append("IF EXISTS")
        sql.append(quote_identifier(column.name))
        settings = ClickHouseDDLHelper.render_settings(kw.get("clickhouse_settings"))
        if settings:
            sql.extend(["SETTINGS", settings])
        self._exec(text(" ".join(sql)))

    def rename_table(
        self,
        old_table_name: str,
        new_table_name: str | quoted_name,
        schema: str | quoted_name | None = None,
    ) -> None:
        sql = f"RENAME TABLE {full_table(old_table_name, schema)} TO {full_table(new_table_name, schema)}"
        self._exec(text(sql))

    def create_index(self, index: Index, **kw: Any) -> None:
        _reject_standard_index()

    def drop_index(self, index: Index, **kw: Any) -> None:
        _reject_standard_index()

    def create_table_comment(self, table: Table) -> None:
        self._exec(text(self._comment_table_sql(table, table.comment)))

    def drop_table_comment(self, table: Table) -> None:
        self._exec(text(self._comment_table_sql(table, None)))

    def alter_column(
        self,
        table_name: str,
        column_name: str,
        *,
        nullable: bool | None = None,
        server_default: Any = False,
        name: str | None = None,
        type_: Any = None,
        schema: str | None = None,
        autoincrement: bool | None = None,
        comment: Any = False,
        existing_comment: str | None = None,
        existing_type: Any = None,
        existing_server_default: Any = None,
        existing_nullable: bool | None = None,
        existing_autoincrement: bool | None = None,
        if_exists: bool | None = None,
        **kw: Any,
    ) -> None:
        """Render ClickHouse column rename, comment, type, default, and nullable alters."""
        if autoincrement is not None or existing_autoincrement is not None:
            return
        if name is not None:
            rename_sql = ["ALTER TABLE", full_table(table_name, schema), "RENAME COLUMN"]
            if if_exists:
                rename_sql.append("IF EXISTS")
            rename_sql.extend([quote_identifier(column_name), "TO", quote_identifier(name)])
            self._exec(text(" ".join(rename_sql)))
            column_name = name

        settings = ClickHouseDDLHelper.render_settings(kw.get("clickhouse_settings"))
        will_modify = nullable is not None or server_default is not False or type_ is not None

        if comment is not False and not will_modify:
            self._exec(text(self._comment_column_sql(table_name, column_name, comment, schema, settings)))

        if not will_modify:
            return

        if type_ is not None:
            effective_type = type_
        else:
            effective_type = existing_type
        if effective_type is None:
            raise CommandError(f"ClickHouse alter_column requires existing_type for {table_name}.{column_name}")
        if nullable is not None:
            effective_type = self._set_type_nullable(effective_type, nullable)

        sql = [
            "ALTER TABLE",
            full_table(table_name, schema),
            "MODIFY COLUMN",
        ]
        if if_exists:
            sql.append("IF EXISTS")
        sql.append(
            column_specification(
                self.dialect,
                Column(
                    column_name,
                    effective_type,
                    server_default=None if server_default is False else server_default,
                    comment=existing_comment if comment is False else comment,
                ),
            )
        )
        if settings:
            sql.extend(["SETTINGS", settings])
        self._exec(text(" ".join(sql)))

    def compare_type(self, inspector_column: Any, metadata_column: Any) -> bool:
        """Compare reflected and metadata ClickHouse column types for autogenerate."""
        inspector_type = inspector_column.type
        metadata_type = metadata_column.type
        explicit_nullable = ClickHouseDDLHelper.explicit_column_nullable(metadata_column)
        if explicit_nullable is None and isinstance(inspector_type, ChSqlaType) and isinstance(metadata_type, ChSqlaType):
            inspector_type = ClickHouseDDLHelper.without_nullable(inspector_type)
            metadata_type = ClickHouseDDLHelper.without_nullable(metadata_type)
        else:
            metadata_type = ClickHouseDDLHelper.effective_column_type(metadata_column)
        if self._normalize_type_name(inspector_type) == self._normalize_type_name(metadata_type):
            return False
        while isinstance(inspector_type, TypeDecorator):
            inspector_type = inspector_type.type_engine(self.dialect)
        while isinstance(metadata_type, TypeDecorator):
            metadata_type = metadata_type.type_engine(self.dialect)
        if isinstance(inspector_type, ChSqlaType) and isinstance(metadata_type, ChSqlaType):
            return not self._type_names_match(inspector_type.name, metadata_type.name)
        return True

    @classmethod
    def _type_names_match(cls, inspector_name: str, metadata_name: str) -> bool:
        if cls._normalize_type_name(inspector_name) == cls._normalize_type_name(metadata_name):
            return True
        inspector_base, _, inspector_def = parse_name(inspector_name)
        metadata_base, _, metadata_def = parse_name(metadata_name)
        if inspector_base != metadata_base or inspector_def.wrappers != metadata_def.wrappers or inspector_def.keys != metadata_def.keys:
            return False
        inspector_args = inspector_def.values
        metadata_args = metadata_def.values
        if metadata_base == "Variant":
            if len(inspector_args) != len(metadata_args):
                return False
            # The client sorts pinned uniq version 1 before unversioned sum,
            # which reverses their order relative to unversioned metadata.
            candidates = [
                [
                    inspector_index
                    for inspector_index, inspector_arg in enumerate(inspector_args)
                    if cls._type_names_match(str(inspector_arg), str(metadata_arg))
                ]
                for metadata_arg in metadata_args
            ]
            matched_metadata = [-1] * len(inspector_args)

            def match_member(metadata_index: int, visited: set[int]) -> bool:
                for inspector_index in candidates[metadata_index]:
                    if inspector_index in visited:
                        continue
                    visited.add(inspector_index)
                    previous = matched_metadata[inspector_index]
                    if previous == -1 or match_member(previous, visited):
                        matched_metadata[inspector_index] = metadata_index
                        return True
                return False

            return all(match_member(metadata_index, set()) for metadata_index in range(len(metadata_args)))
        if metadata_base.lower() == "aggregatefunction":
            # Omitted metadata versions preserve the reflected state version.
            if metadata_args and isinstance(metadata_args[0], int):
                inspector_version = inspector_args[0] if inspector_args and isinstance(inspector_args[0], int) else 0
                if inspector_version != metadata_args[0]:
                    return False
                metadata_args = metadata_args[1:]
                if inspector_args and isinstance(inspector_args[0], int):
                    inspector_args = inspector_args[1:]
            elif inspector_args and isinstance(inspector_args[0], int):
                inspector_args = inspector_args[1:]
            if not inspector_args or not metadata_args:
                return False
            if cls._normalize_type_name(inspector_args[0]) != cls._normalize_type_name(metadata_args[0]):
                return False
            inspector_args = inspector_args[1:]
            metadata_args = metadata_args[1:]
        elif metadata_base not in ("Array", "Map", "Tuple", "Nested", "SimpleAggregateFunction"):
            return False
        return len(inspector_args) == len(metadata_args) and all(
            cls._type_names_match(str(inspector_arg), str(metadata_arg))
            for inspector_arg, metadata_arg in zip(inspector_args, metadata_args)
        )

    def compare_server_default(
        self,
        inspector_column: Any,
        metadata_column: Any,
        rendered_metadata_default: Any,
        rendered_inspector_default: Any,
    ) -> bool:
        """Compare normalized ClickHouse server defaults for autogenerate."""
        return self._normalize_default(rendered_inspector_default) != self._normalize_default(rendered_metadata_default)

    def render_type(self, type_obj: Any, autogen_context: Any) -> str | Literal[False]:
        """Render ClickHouse SQLAlchemy types as migration Python source."""
        if not isinstance(type_obj, ChSqlaType):
            return False
        return _render_ch_type(type_obj)

    def _exec_version_update(self, construct: Update, execution_options=None):
        # Alembic emits a normal SQLAlchemy Update here, but ClickHouse version tracking
        # needs insert + mutation delete semantics. SQLAlchemy does not expose a stable
        # public API for these values across versions, so this depends on the current
        # Update internals.
        values = construct._values
        if not values:
            raise CommandError("ClickHouse Alembic version update is missing values")
        version_value = self._compile_clause(list(values.values())[0])
        where_clause = self._compile_version_where(construct)
        self._exec(text(f"INSERT INTO {self._version_table_name} (version_num) VALUES ({version_value})"))
        self._exec(text(f"ALTER TABLE {self._version_table_name} DELETE WHERE {where_clause} SETTINGS mutations_sync = 2"))
        return SimpleNamespace(rowcount=1)

    def _exec_version_delete(self, construct: Delete, execution_options=None):
        where_clause = self._compile_version_where(construct)
        return super()._exec(
            text(f"ALTER TABLE {self._version_table_name} DELETE WHERE {where_clause} SETTINGS mutations_sync = 2"),
            execution_options=execution_options,
        )

    @property
    def _version_table_name(self) -> str:
        schema = self.context_opts.get("version_table_schema")
        table = self.context_opts.get("version_table", "alembic_version")
        if schema:
            return f"{quote_identifier(schema)}.{quote_identifier(table)}"
        return quote_identifier(table)

    def _is_version_table_construct(self, construct) -> bool:
        table = getattr(construct, "table", None)
        if table is None:
            return False
        if table.name != self.context_opts.get("version_table", "alembic_version"):
            return False
        expected_schema = self.context_opts.get("version_table_schema")
        # Alembic captures version_table_schema before ClickHouseImpl.__init__
        # has a chance to set it, so the _version Table may have schema=None
        # while context_opts has the auto-detected database name.
        if table.schema == expected_schema:
            return True
        if table.schema is None and expected_schema is not None:
            return True
        return False

    def _compile_version_where(self, construct) -> str:
        predicates = []
        for expression in construct._where_criteria:
            # SQLAlchemy does not provide a public helper for pulling these predicates
            # back apart, so this relies on the current binary expression structure.
            column_name = getattr(getattr(expression, "left", None), "name", None)
            if not column_name:
                predicates.append(self._compile_clause(expression))
                continue
            right = self._compile_clause(expression.right)
            predicates.append(f"{quote_identifier(column_name)} = {right}")
        return " AND ".join(predicates)

    def _compile_clause(self, clause) -> str:
        return str(
            clause.compile(
                dialect=self.dialect,
                compile_kwargs={"literal_binds": True},
            )
        )

    def _comment_column_sql(
        self,
        table_name: str,
        column_name: str,
        comment: str | None,
        schema: str | None,
        settings: str,
    ) -> str:
        sql = [
            "ALTER TABLE",
            full_table(table_name, schema),
            "COMMENT COLUMN",
            quote_identifier(column_name),
            ClickHouseDDLHelper.render_comment(comment),
        ]
        if settings:
            sql.extend(["SETTINGS", settings])
        return " ".join(sql)

    @staticmethod
    def _comment_table_sql(table: Table, comment: str | None) -> str:
        return " ".join(
            [
                "ALTER TABLE",
                full_table(table.name, table.schema),
                "MODIFY COMMENT",
                ClickHouseDDLHelper.render_comment(comment),
            ]
        )

    @staticmethod
    def _normalize_default(default: str | None) -> str | None:
        if default is None:
            return None
        return default.strip()

    @staticmethod
    def _normalize_type_name(type_: Any) -> str:
        type_name = str(type_.name) if hasattr(type_, "name") else str(type_)
        normalized: list[str] = []
        quote: str | None = None
        pos = 0
        while pos < len(type_name):
            char = type_name[pos]
            if quote:
                normalized.append(char)
                if char == "\\" and pos + 1 < len(type_name):
                    pos += 1
                    normalized.append(type_name[pos])
                elif char == quote and pos + 1 < len(type_name) and type_name[pos + 1] == quote:
                    pos += 1
                    normalized.append(type_name[pos])
                elif char == quote:
                    quote = None
            elif char in ("'", '"', "`"):
                quote = char
                normalized.append(char)
            elif not char.isspace():
                normalized.append(char)
            pos += 1
        return "".join(normalized)

    @staticmethod
    def _set_type_nullable(type_: Any, nullable: bool):
        if isinstance(type_, type) and issubclass(type_, ChSqlaType):
            type_ = type_()
        if not isinstance(type_, ChSqlaType):
            return type_
        if nullable:
            if type_.nullable:
                return type_

            return Nullable(type_)
        if not type_.nullable:
            return type_
        wrappers = tuple(wrapper for wrapper in type_.type_def.wrappers if wrapper != "Nullable")
        return type_.__class__(type_def=type_.type_def.__class__(wrappers, type_.type_def.keys, type_.type_def.values))
